<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR">
<context>
    <name>AlbumDelegate</name>
    <message>
        <location filename="../PhotoViewerCore/AlbumDelegate.qml" line="59"/>
        <source>Remove</source>
        <translation>Supprimer</translation>
    </message>
</context>
<context>
    <name>photoviewer</name>
    <message>
        <location filename="../photoviewer.qml" line="30"/>
        <source>Add</source>
        <translation>Ajouter</translation>
    </message>
    <message>
        <location filename="../photoviewer.qml" line="39"/>
        <source>Edit</source>
        <translation>Éditer</translation>
    </message>
    <message>
        <location filename="../photoviewer.qml" line="52"/>
        <source>Back</source>
        <translation>Retour</translation>
    </message>
</context>
</TS>
